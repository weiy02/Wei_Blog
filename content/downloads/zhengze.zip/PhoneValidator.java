package study.zhengze;

/**
 * 练习2: 中国手机号码验证
 *
 * 学习要点:
 * - 锚点: ^ 开头, $ 结尾
 * - 字符类: [1][3-9] 表示第一位是1，第二位是3-9
 * - 固定位数: \\d{9} 恰好9位数字
 * - 分组捕获: () 提取号码中的段
 */
public class PhoneValidator {

    /**
     * 校验中国大陆手机号（简单版）
     * 规则: 1开头的11位数字（不考虑号段更新）
     */
    public static boolean isSimplePhone(String phone) {
        if (phone == null) return false;
        return phone.matches("1\\d{10}");
    }

    /**
     * 校验中国大陆手机号（严格版，匹配当前已知号段）
     * 移动: 134-139, 147, 150-152, 157-159, 165, 172-178, 182-184, 187-188, 198
     * 联通: 130-132, 145, 155-156, 166, 171, 175-176, 185-186, 196
     * 电信: 133, 149, 153, 162, 173, 174, 177, 180-181, 189, 190, 191, 199
     * 广电: 192
     */
    public static boolean isStrictPhone(String phone) {
        if (phone == null) return false;
        // 第二位: 3-9 都是合法号段
        String regex = "^1[3-9]\\d{9}$";
        return phone.matches(regex);
    }

    /**
     * 格式化手机号: 13812345678 → 138-1234-5678
     * 使用分组捕获和反向引用
     */
    public static String formatPhone(String phone) {
        if (phone == null || !phone.matches("1\\d{10}")) {
            return "无效手机号";
        }
        return phone.replaceAll("(\\d{3})(\\d{4})(\\d{4})", "$1-$2-$3");
    }

    /**
     * 隐藏中间四位: 13812345678 → 138****5678
     */
    public static String maskPhone(String phone) {
        if (phone == null || !phone.matches("1\\d{10}")) {
            return "无效手机号";
        }
        return phone.replaceAll("(\\d{3})\\d{4}(\\d{4})", "$1****$2");
    }

    /**
     * 从文本中提取所有手机号
     */
    public static String extractPhones(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("1[3-9]\\d{9}");
        java.util.regex.Matcher matcher = pattern.matcher(text);

        StringBuilder result = new StringBuilder("提取到的手机号:\n");
        int count = 0;
        while (matcher.find()) {
            result.append("  ").append(++count).append(". ")
                    .append(matcher.group())
                    .append(" → ")
                    .append(formatPhone(matcher.group()))
                    .append(" → ")
                    .append(maskPhone(matcher.group()))
                    .append("\n");
        }
        if (count == 0) {
            return "未找到手机号";
        }
        return result.toString();
    }

    public static void main(String[] args) {
        System.out.println("========== 手机号验证器 ==========");
        System.out.println();

        String[] phones = {
                "13812345678",
                "15912345678",
                "10086100101",     // 特殊号码
                "12345678901",     // 非法：第二位是2
                "1381234567",      // 非法：10位
                "138123456789",    // 非法：12位
                "abc13812345678",  // 带有前缀
        };

        System.out.println("--- 手机号校验 ---");
        System.out.printf("  %-20s %-10s %-10s%n", "号码", "简单版", "严格版");
        System.out.println("  " + "-".repeat(42));
        for (String phone : phones) {
            System.out.printf("  %-20s %-10s %-10s%n",
                    phone, isSimplePhone(phone), isStrictPhone(phone));
        }

        System.out.println();
        System.out.println("--- 格式化 ---");
        System.out.printf("  %-15s → %-15s → %-15s%n", "原号", "格式化", "脱敏");
        System.out.println("  " + "-".repeat(49));
        String[] validPhones = {"13812345678", "15998765432", "18800001111"};
        for (String p : validPhones) {
            System.out.printf("  %-15s → %-15s → %-15s%n", p, formatPhone(p), maskPhone(p));
        }

        System.out.println();
        System.out.println("--- 从文本提取 ---");
        String text = "请联系 13812345678 或 15998765432，紧急请打 18800001111。";
        System.out.println("  原文: " + text);
        System.out.println();
        System.out.println(extractPhones(text));
    }
}
