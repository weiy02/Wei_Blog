package study.zhengze;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 练习6: 高级正则特性
 *
 * 学习要点:
 * - 零宽断言: 前瞻 (?=), 负前瞻 (?!), 后顾 (?<=), 负后顾 (?<!)
 * - 非捕获组: (?:pattern) 分组但不捕获，性能更好
 * - 占有量词: ++ 一次性匹配，不回溯（防止灾难性回溯）
 * - 回溯陷阱与性能优化
 * - Pattern.quote() 安全地转义字面量文本
 */
public class AdvancedRegex {

    /**
     * 演示零宽断言（Lookahead / Lookbehind）
     */
    public static String demoLookaround() {
        String text = "苹果100元，香蕉50元，合计150元";

        StringBuilder result = new StringBuilder("--- 零宽断言 ---\n\n");
        result.append("  原文: \"").append(text).append("\"\n\n");

        // 正向前瞻 (?=pattern) — 匹配后面跟着"元"的数字
        Pattern lookahead = Pattern.compile("\\d+(?=元)");
        Matcher m1 = lookahead.matcher(text);
        result.append("  正向前瞻 \\d+(?=元) — 匹配后面是\"元\"的数字:\n");
        while (m1.find()) {
            result.append("    → ").append(m1.group()).append("\n");
        }

        // 负向前瞻 (?!pattern) — 匹配后面不跟着"元"的数字
        Pattern negativeLookahead = Pattern.compile("\\d+(?!元)");
        Matcher m2 = negativeLookahead.matcher(text);
        result.append("\n  负向前瞻 \\d+(?!元) — 匹配后面不是\"元\"的数字:\n");
        while (m2.find()) {
            result.append("    → ").append(m2.group()).append("\n");
        }

        return result.toString();
    }

    /**
     * 演示正向后顾：提取价格
     */
    public static String demoLookbehind() {
        String text = "单价: $19.99, 折扣价: $9.99, 原价: 29.99";

        StringBuilder result = new StringBuilder("--- 正向后顾 ---\n\n");
        result.append("  原文: \"").append(text).append("\"\n\n");

        // 正向后顾 (?<=pattern) — 匹配"$"后面的数字
        Pattern lookbehind = Pattern.compile("(?<=\\$)\\d+\\.\\d{2}");
        Matcher matcher = lookbehind.matcher(text);
        result.append("  正向后顾 (?<=\\$)\\d+\\.\\d{2} — 匹配 $ 后面的价格:\n");
        while (matcher.find()) {
            result.append("    → ").append(matcher.group()).append("\n");
        }

        // 组合使用: 提取"单价:"后面的内容
        Pattern combined = Pattern.compile("(?<=单价: ).*(?=,)");
        Matcher m2 = combined.matcher(text);
        if (m2.find()) {
            result.append("\n  组合断言 (?<=单价: ).*(?=,) — 提取\"单价:\"和逗号之间的内容:\n");
            result.append("    → ").append(m2.group()).append("\n");
        }

        return result.toString();
    }

    /**
     * 演示非捕获组 (?:pattern) 与捕获组的性能对比
     */
    public static String demoNonCapturingGroup() {
        String text = "abc-123-def-456-ghi-789";

        StringBuilder result = new StringBuilder("--- 非捕获组 vs 捕获组 ---\n\n");
        result.append("  原文: \"").append(text).append("\"\n\n");

        // 使用捕获组
        Pattern capture = Pattern.compile("(\\w{3})-");
        Matcher m1 = capture.matcher(text);
        result.append("  捕获组 (\\\\w{3})- :\n");
        while (m1.find()) {
            result.append("    完整匹配: \"").append(m1.group())
                    .append("\", 捕获组1: \"").append(m1.group(1)).append("\"\n");
        }

        // 使用非捕获组
        Pattern nonCapture = Pattern.compile("(?:\\w{3})-");
        Matcher m2 = nonCapture.matcher(text);
        result.append("\n  非捕获组 (?:\\\\w{3})- :\n");
        while (m2.find()) {
            result.append("    匹配: \"").append(m2.group()).append("\"");
            result.append(" (不占用捕获组编号, 速度更快)\n");
        }

        result.append("\n  区别: 非捕获组 (?:) 节省内存和计算，不需要捕获的用非捕获组\n");
        result.append("  建议: 不需要提取分组内容时，优先用 (?:) 而非 ()\n");

        return result.toString();
    }

    /**
     * 演示 Pattern.quote() — 安全处理用户输入中的特殊字符
     */
    public static String demoQuote() {
        StringBuilder result = new StringBuilder("--- Pattern.quote() 安全转义 ---\n\n");

        String userInput = "hello.world (test) [1+2] $100";
        String searchTerm = ".";  // 点号在正则中是特殊字符

        // 不安全的方式
        Pattern unsafe = Pattern.compile(searchTerm);
        Matcher m1 = unsafe.matcher(userInput);
        int count1 = 0;
        while (m1.find()) count1++;

        // 安全的方式
        Pattern safe = Pattern.compile(Pattern.quote(searchTerm));
        Matcher m2 = safe.matcher(userInput);
        int count2 = 0;
        while (m2.find()) count2++;

        result.append("  文本: \"").append(userInput).append("\"\n");
        result.append("  搜索: ").append(searchTerm).append(" (点号是正则元字符)\n\n");
        result.append("  Pattern.compile(\".\"):               找到 ").append(count1).append(" 个（匹配任意字符!）\n");
        result.append("  Pattern.compile(Pattern.quote(\".\")): 找到 ").append(count2).append(" 个（匹配字面量点号）\n");

        return result.toString();
    }

    /**
     * 演示回溯陷阱与性能对比
     *
     * 灾难性回溯经典例子:
     *    (a+)+b  匹配 "aaaaaaaaac" → 指数级回溯
     *    用 (a++)+b（占有量词）可解决
     */
    public static String demoBacktracking() {
        StringBuilder result = new StringBuilder("--- 回溯陷阱与占有量词 ---\n\n");

        String text = "aaaaaaaac";  // 末尾没有 b

        // 方法1: 普通量词 — 会灾难性回溯
        Pattern greedyPattern = Pattern.compile("(a+)+b");
        Matcher greedyMatcher = greedyPattern.matcher(text);

        long start1 = System.nanoTime();
        boolean greedyResult = greedyMatcher.matches();
        long end1 = System.nanoTime();

        // 方法2: 占有量词 — 不会回溯
        Pattern possessivePattern = Pattern.compile("(a++)+b");
        Matcher possessiveMatcher = possessivePattern.matcher(text);

        long start2 = System.nanoTime();
        boolean possessiveResult = possessiveMatcher.matches();
        long end2 = System.nanoTime();

        double time1 = (end1 - start1) / 1_000_000.0;
        double time2 = (end2 - start2) / 1_000_000.0;

        result.append("  匹配 \"").append(text).append("\" 是否匹配 a+)+b\n\n");
        result.append(String.format("  贪婪量词 (a+)+b:   %-5s  耗时 %.2f ms%n", greedyResult, time1));
        result.append(String.format("  占有量词 (a++)+b: %-5s  耗时 %.2f ms%n", possessiveResult, time2));

        String times;
        if (time1 > time2 * 10) {
            times = "  差距 " + String.format("%.0f", time1 / time2) + " 倍！占有量词性能显著更优！";
        } else {
            times = "  两者差距不大（较短字符串）";
        }
        result.append("\n").append(times).append("\n\n");
        result.append("  简单规则: 确定不需要回溯时，用 ++ / *+ / ?+ 代替 + / * / ?\n");

        return result.toString();
    }

    /**
     * 综合示例：从HTML中提取链接（但建议实际用解析器）
     */
    public static String demoHtmlLinkExtractor() {
        String html = """
                <html>
                <a href="https://example.com">Example</a>
                <a href='http://test.org/page?q=1'>Test</a>
                <a href="javascript:void(0)">JS</a>
                <a href="/relative/path">Relative</a>
                </html>
                """;

        // 非贪婪匹配 *? 确保匹配到最近的引号
        Pattern pattern = Pattern.compile("href=\"(https?://[^\"]+)\"");
        Matcher matcher = pattern.matcher(html);

        StringBuilder result = new StringBuilder("--- 提取HTML中的http链接 ---\n\n");
        result.append("  模拟HTML:\n").append(html).append("\n");
        result.append("  匹配 href=\"https?://...\":\n");

        int count = 0;
        while (matcher.find()) {
            result.append("    ").append(++count).append(". ").append(matcher.group(1)).append("\n");
        }
        if (count == 0) result.append("    (无匹配)\n");

        return result.toString();
    }

    public static void main(String[] args) {
        System.out.println("========== 高级正则特性 ==========");
        System.out.println();

        System.out.println(demoLookaround());
        System.out.println();

        System.out.println(demoLookbehind());
        System.out.println();

        System.out.println(demoNonCapturingGroup());
        System.out.println();

        System.out.println(demoQuote());
        System.out.println();

        System.out.println(demoBacktracking());
        System.out.println();

        System.out.println(demoHtmlLinkExtractor());
        System.out.println();

        System.out.println("--- 实用记忆卡片 ---");
        System.out.println("  (?=...)      前瞻     匹配后面是...的位置");
        System.out.println("  (?!...)      负前瞻   匹配后面不是...的位置");
        System.out.println("  (?<=...)     后顾     匹配前面是...的位置");
        System.out.println("  (?<!...)     负后顾   匹配前面不是...的位置");
        System.out.println("  (?:...)      非捕获组 分组但不捕获，性能更好");
        System.out.println("  ++, *+, ?+   占有量词 不回溯，防止灾难性回溯");
        System.out.println("  *?, +?, ??   懒惰量词 匹配尽可能少");
        System.out.println("  Pattern.quote()  安全转义用户输入");
    }
}
