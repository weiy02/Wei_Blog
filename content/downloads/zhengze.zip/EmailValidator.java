package study.zhengze;

/**
 * 练习1: 邮箱地址验证
 *
 * 学习要点:
 * - 常用字符类: [a-zA-Z0-9], \\w (单词字符), \\d (数字)
 * - 量词: + (一次或多次), * (零次或多次), {n,m} (n到m次)
 * - 转义: \\. (对.转义)
 * - 分组: @ 前后分为用户名和域名
 */
public class EmailValidator {

    /**
     * 校验是否为合法的邮箱地址
     * 规则: 用户名@域名.顶级域
     * - 用户名: 字母数字下划线连字符点，长度1-64
     * - 域名: 字母数字连字符，长度1-255
     * - 顶级域: 至少2个字母
     */
    public static boolean isValidEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        String regex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        return email.matches(regex);
    }

    /**
     * 更严格的邮箱校验 —— 只允许常见的邮箱提供商域名
     */
    public static boolean isCommonEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        String regex = "^[a-zA-Z0-9._%+-]+@(gmail|outlook|qq|163|126|yahoo|foxmail)\\.(com|cn|com\\.cn)$";
        return email.matches(regex);
    }

    /**
     * 从文本中提取所有邮箱地址
     */
    public static String extractEmails(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        }
        String regex = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}";
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(regex);
        java.util.regex.Matcher matcher = pattern.matcher(text);

        StringBuilder result = new StringBuilder("提取到的邮箱地址:\n");
        int count = 0;
        while (matcher.find()) {
            result.append("  ").append(++count).append(". ").append(matcher.group()).append("\n");
        }
        if (count == 0) {
            return "未找到邮箱地址";
        }
        return result.toString();
    }

    public static void main(String[] args) {
        System.out.println("========== 邮箱验证器 ==========");
        System.out.println();

        String[] emails = {
                "user@example.com",
                "hello.world@gmail.com",
                "test123@qq.com",
                "invalid-email",
                "user@.com",
                "name@domain.c",
                "user+tag@163.com",
                "@gmail.com",
        };

        System.out.println("--- 基础邮箱校验 ---");
        for (String email : emails) {
            System.out.printf("  %-30s → %s%n", email, isValidEmail(email));
        }

        System.out.println();
        System.out.println("--- 常见邮箱校验 ---");
        String[] commonTests = {
                "user@gmail.com",
                "user@qq.com",
                "user@outlook.com",
                "user@company.org",
        };
        for (String email : commonTests) {
            System.out.printf("  %-30s → %s%n", email, isCommonEmail(email));
        }

        System.out.println();
        System.out.println("--- 从文本提取邮箱 ---");
        String text = "联系方式: admin@example.com, 客服: support@qq.com, " +
                "个人邮箱: someone@gmail.com, 抄送: cc@company.com.cn";
        System.out.println("  原文: " + text);
        System.out.println();
        System.out.println(extractEmails(text));

        System.out.println("--- String.matches() 与 Pattern/Matcher 的区别 ---");
        System.out.println("  String.matches() 必须匹配整个字符串（隐式加 ^ 和 $）");
        System.out.println("  Pattern/Matcher.find() 匹配子串，更灵活");
    }
}
