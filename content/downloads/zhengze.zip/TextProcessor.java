package study.zhengze;

/**
 * 练习4: 文本处理 —— 替换、分割、查找
 *
 * 学习要点:
 * - String.replaceAll() / replaceFirst() 替换
 * - String.split() 分割
 * - Pattern/Matcher 循环查找
 * - 零宽断言: (?=...) 前瞻, (?<=...) 后顾, (?!...) 负前瞻
 */
public class TextProcessor {

    /**
     * 去除多余空格：将连续多个空格替换为单个
     */
    public static String normalizeSpaces(String text) {
        if (text == null) return "";
        return text.trim().replaceAll("\\s+", " ");
    }

    /**
     * 去除所有空白字符（包括换行、制表符）
     */
    public static String removeAllWhitespace(String text) {
        if (text == null) return "";
        return text.replaceAll("\\s+", "");
    }

    /**
     * 将驼峰命名转为下划线命名: userName → user_name
     */
    public static String camelToSnake(String camel) {
        if (camel == null || camel.isEmpty()) return "";
        // (?<=[a-z])(?=[A-Z]) 零宽断言：匹配小写字母和大写字母之间的位置
        return camel.replaceAll("(?<=[a-z])(?=[A-Z])", "_")
                    .toLowerCase();
    }

    /**
     * 将下划线命名转为驼峰命名: user_name → userName
     */
    public static String snakeToCamel(String snake) {
        if (snake == null || snake.isEmpty()) return "";
        String[] parts = snake.split("_");
        StringBuilder result = new StringBuilder(parts[0]);
        for (int i = 1; i < parts.length; i++) {
            if (!parts[i].isEmpty()) {
                result.append(Character.toUpperCase(parts[i].charAt(0)));
                if (parts[i].length() > 1) {
                    result.append(parts[i].substring(1));
                }
            }
        }
        return result.toString();
    }

    /**
     * 使用 split 分割字符串 —— 多种场景
     */
    public static String demonstrateSplit(String text, String regex) {
        if (text == null || regex == null) return "";
        String[] parts = text.split(regex);
        // 如果分割后只有一个元素且等于原文，说明未匹配到分隔符
        if (parts.length == 1 && parts[0].equals(text)) {
            return "未找到匹配的分隔符";
        }
        StringBuilder result = new StringBuilder("分割结果 (").append(parts.length).append(" 段):\n");
        for (int i = 0; i < parts.length; i++) {
            result.append("  [").append(i).append("] \"").append(parts[i]).append("\"\n");
        }
        return result.toString();
    }

    /**
     * 统计单词出现次数（忽略大小写）
     */
    public static int countWord(String text, String word) {
        if (text == null || word == null || word.isEmpty()) return 0;
        // 使用 \b 单词边界确保全词匹配
        String regex = "\\b" + java.util.regex.Pattern.quote(word) + "\\b";
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(regex,
                java.util.regex.Pattern.CASE_INSENSITIVE);
        java.util.regex.Matcher matcher = pattern.matcher(text);
        int count = 0;
        while (matcher.find()) {
            count++;
        }
        return count;
    }

    /**
     * 查找并标注所有匹配项
     */
    public static String highlightMatches(String text, String regex) {
        if (text == null || regex == null) return "";
        return text.replaceAll(regex, "「$0」");
    }

    public static void main(String[] args) {
        System.out.println("========== 文本处理器 ==========");
        System.out.println();

        // -------- 空格处理 --------
        System.out.println("--- 空格规范化 ---");
        String messy = "   Hello    World!   Java  正则 表达式  ";
        System.out.println("  原文:    \"" + messy + "\"");
        System.out.println("  规范化:  \"" + normalizeSpaces(messy) + "\"");
        System.out.println("  去空白:  \"" + removeAllWhitespace(messy) + "\"");

        System.out.println();

        // -------- 命名转换 --------
        System.out.println("--- 命名风格转换 ---");
        String[] camelCases = {"userName", "firstName", "camelToSnake", "XMLParser", "getURLAddress"};
        System.out.printf("  %-20s → %-20s%n", "驼峰", "下划线");
        System.out.println("  " + "-".repeat(42));
        for (String c : camelCases) {
            System.out.printf("  %-20s → %-20s%n", c, camelToSnake(c));
        }

        System.out.println();
        String[] snakeCases = {"user_name", "first_name", "camel_to_snake", "xml_parser"};
        System.out.printf("  %-20s → %-20s%n", "下划线", "驼峰");
        System.out.println("  " + "-".repeat(42));
        for (String s : snakeCases) {
            System.out.printf("  %-20s → %-20s%n", s, snakeToCamel(s));
        }

        System.out.println();

        // -------- 分割演示 --------
        System.out.println("--- 分割字符串 ---");
        System.out.println("  按逗号分割:");
        System.out.println(demonstrateSplit("apple,banana,orange,grape", ","));
        System.out.println("  按多个分隔符分割:");
        System.out.println(demonstrateSplit("a,b;c|d:e f", "[,;|:\\s]"));
        System.out.println("  保留空字符串（limit = -1）:");
        String csv = "a,,b,,,c";
        String[] parts = csv.split(",", -1);
        System.out.println("  分割 \"" + csv + "\" 保留空 → " + parts.length + " 段");
        for (int i = 0; i < parts.length; i++) {
            System.out.println("    [" + i + "] \"" + parts[i] + "\"");
        }

        System.out.println();

        // -------- 单词统计 --------
        System.out.println("--- 单词计数 ---");
        String passage = "Java is great. Java is powerful. Java is everywhere! I love Java.";
        String word = "Java";
        int count = countWord(passage, word);
        System.out.println("  原文: " + passage);
        System.out.println("  \"" + word + "\" 出现了 " + count + " 次");

        System.out.println();

        // -------- 高亮匹配 --------
        System.out.println("--- 高亮匹配 ---");
        String html = "Contact: admin@example.com and support@test.org";
        String emailRegex = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}";
        System.out.println("  原文: " + html);
        System.out.println("  高亮: " + highlightMatches(html, emailRegex));
    }
}
