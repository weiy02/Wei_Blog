package study.zhengze;

/**
 * 练习3: 身份证号码验证
 *
 * 学习要点:
 * - 分组: 将身份证拆分为省市、出生日期、顺序码、校验码
 * - 或运算: [0-9Xx] 最后一位可以是数字或X
 * - 量词精确控制: \\d{6}, \\d{4}
 * - java.time 与正则结合进行语义校验
 */
public class IdCardValidator {

    /**
     * 校验18位身份证号的基本格式
     * 规则: 6位地区码 + 8位生日(yyyyMMdd) + 3位顺序码 + 1位校验码(数字或X)
     */
    public static boolean isValidFormat(String id) {
        if (id == null) return false;
        return id.matches("^[1-9]\\d{5}(19|20)\\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\\d|3[01])\\d{3}[0-9Xx]$");
    }

    /**
     * 从身份证号中提取生日
     */
    public static String extractBirthday(String id) {
        if (!isValidFormat(id)) {
            return "无效身份证号";
        }
        // 使用命名捕获组（Java 7+）
        java.util.regex.Pattern pattern =
                java.util.regex.Pattern.compile("(?<year>\\d{4})(?<month>\\d{2})(?<day>\\d{2})");
        java.util.regex.Matcher matcher = pattern.matcher(id.substring(6, 14));

        if (matcher.find()) {
            String year = matcher.group("year");
            String month = matcher.group("month");
            String day = matcher.group("day");
            return year + "年" + month + "月" + day + "日";
        }
        return "未知";
    }

    /**
     * 从身份证号推断性别（顺序码奇数=男，偶数=女）
     */
    public static String guessGender(String id) {
        if (!isValidFormat(id)) {
            return "无效身份证号";
        }
        // 第17位（顺序码的第1位）决定性别
        char genderCode = id.charAt(16);
        int code = genderCode - '0';
        return (code % 2 == 1) ? "男" : "女";
    }

    /**
     * 从身份证号提取地区码（前6位）和出生日期（中间8位）等信息
     */
    public static String parseIdCard(String id) {
        if (!isValidFormat(id)) {
            return "无效身份证号";
        }
        // 用分组捕获一次性提取各部分
        String regex = "^([1-9]\\d{5})(\\d{4})(\\d{2})(\\d{2})(\\d{3})([0-9Xx])$";
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(regex);
        java.util.regex.Matcher matcher = pattern.matcher(id);

        if (matcher.find()) {
            String region = matcher.group(1);
            String year = matcher.group(2);
            String month = matcher.group(3);
            String day = matcher.group(4);
            String seq = matcher.group(5);
            String check = matcher.group(6).toUpperCase();

            return String.format("""
                    身份证解析结果:
                      地区码: %s
                      出生日期: %s年%s月%s日
                      顺序码: %s (性别: %s)
                      校验码: %s""",
                    region, year, month, day, seq,
                    (Integer.parseInt(seq) % 2 == 1) ? "男" : "女",
                    check);
        }
        return "解析失败";
    }

    /**
     * 校验码验证（ISO 7064:1983, MOD 11-2 算法）
     */
    public static boolean verifyCheckCode(String id) {
        if (!isValidFormat(id)) return false;

        int[] weights = {7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2};
        char[] checkChars = {'1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'};

        int sum = 0;
        for (int i = 0; i < 17; i++) {
            sum += (id.charAt(i) - '0') * weights[i];
        }
        int mod = sum % 11;
        char expectedCheck = checkChars[mod];
        char actualCheck = Character.toUpperCase(id.charAt(17));

        return actualCheck == expectedCheck;
    }

    public static void main(String[] args) {
        System.out.println("========== 身份证号验证器 ==========");
        System.out.println();

        String[] ids = {
                "110105200003074338",   // 合法示例
                "440106199001011234",   // 合法示例
                "12345619900101123X",   // 地区码不能以0开头 → 合法但地区码格式正确（已修正）
                "110105200013074338",   // 月份非法（13月）
                "110105200002304338",   // 2月30日非法（语义上）
                "11010520000307433",     // 少一位
                "12345678901234567X",   // 18位但地区码以1开头没问题，待验证
        };

        System.out.println("--- 格式校验 ---");
        System.out.printf("  %-24s %-10s %-12s %-5s%n", "身份证号", "格式", "生日", "性别");
        System.out.println("  " + "-".repeat(55));
        for (String id : ids) {
            System.out.printf("  %-24s %-10s %-12s %-5s%n",
                    id, isValidFormat(id), extractBirthday(id), guessGender(id));
        }

        System.out.println();
        System.out.println("--- 校验码验证（可用性校验）---");
        String[] testIds = {"110105200003074338", "440106199001011234"};
        for (String id : testIds) {
            System.out.println("  " + id + " → 校验码" + (verifyCheckCode(id) ? "✓ 正确" : "✗ 错误"));
        }

        System.out.println();
        System.out.println("--- 完整解析 ---");
        System.out.println(parseIdCard("110105200003074338"));
    }
}
