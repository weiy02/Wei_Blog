package study.zhengze;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 练习5: Pattern 和 Matcher 核心 API 详解
 *
 * 学习要点:
 * - Pattern.compile() 编译正则
 * - Matcher 的 find(), matches(), lookingAt(), group(), start(), end()
 * - Pattern 的 flags: CASE_INSENSITIVE, MULTILINE, DOTALL 等
 * - 性能优化: 重复使用 Pattern（编译一次，多次匹配）
 */
public class PatternMatcherDemo {

    /**
     * 演示 Pattern.compile() 复用 —— 正确的性能实践
     */
    private static final Pattern IP_PATTERN =
            Pattern.compile("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$");

    public static boolean isValidIp(String ip) {
        if (ip == null) return false;
        Matcher matcher = IP_PATTERN.matcher(ip);
        if (!matcher.matches()) return false;

        // 验证每个数字在 0-255 范围内
        for (int i = 1; i <= 4; i++) {
            int segment = Integer.parseInt(matcher.group(i));
            if (segment < 0 || segment > 255) return false;
        }
        return true;
    }

    /**
     * 演示 find() — 查找所有匹配子串
     */
    public static String demoFind() {
        String text = "The cat and the dog chased the bat in the hat.";
        Pattern pattern = Pattern.compile(".at");  // 匹配任何 "某字符+at"
        Matcher matcher = pattern.matcher(text);

        StringBuilder result = new StringBuilder("find() 查找 \"" + pattern.pattern() + "\" 在:\n");
        result.append("  \"").append(text).append("\"\n\n");
        result.append("  匹配结果:\n");

        while (matcher.find()) {
            result.append(String.format("    找到 \"%s\" 在 [%d, %d)%n",
                    matcher.group(), matcher.start(), matcher.end()));
        }
        return result.toString();
    }

    /**
     * 演示 matches() vs find() vs lookingAt()
     */
    public static String demoThreeMethods() {
        String[] texts = {"hello123", "hello", "123hello", "HELLO"};
        Pattern pattern = Pattern.compile("[a-z]+", Pattern.CASE_INSENSITIVE);

        StringBuilder result = new StringBuilder("--- matches() vs find() vs lookingAt() ---\n\n");
        result.append(String.format("  %-12s %-12s %-12s %-12s%n", "文本", "matches()", "find()", "lookingAt()"));
        result.append("  " + "-".repeat(50) + "\n");

        for (String text : texts) {
            Matcher m = pattern.matcher(text);
            result.append(String.format("  %-12s %-12s %-12s %-12s%n",
                    "\"" + text + "\"",
                    m.matches(),
                    m.reset().find(),     // reset() 重置匹配器
                    m.reset().lookingAt()));
        }

        result.append("\n  matches()   — 必须完全匹配整个字符串（隐式加 ^...$）\n");
        result.append("  find()      — 查找任意位置的子串\n");
        result.append("  lookingAt() — 从开头匹配，但不需要匹配到结尾\n");

        return result.toString();
    }

    /**
     * 演示 Pattern flags
     */
    public static String demoFlags() {
        String text = "Hello\nWorld\nHELLO\nworld";

        StringBuilder result = new StringBuilder("--- Pattern Flags 演示 ---\n\n");
        result.append("  文本:\n");
        for (String line : text.split("\n")) {
            result.append("    \"").append(line).append("\"\n");
        }
        result.append("\n");

        // 默认模式（区分大小写）
        Pattern defaultPattern = Pattern.compile("hello");
        Matcher m1 = defaultPattern.matcher(text);
        int count = 0;
        while (m1.find()) count++;
        result.append("  默认 (区分大小写): 找到 " + count + " 个匹配\n");

        // CASE_INSENSITIVE
        Pattern caseInsensitive = Pattern.compile("hello", Pattern.CASE_INSENSITIVE);
        Matcher m2 = caseInsensitive.matcher(text);
        count = 0;
        while (m2.find()) count++;
        result.append("  CASE_INSENSITIVE:  找到 " + count + " 个匹配\n");

        // 加上 (?i) 内联标志 等价于 CASE_INSENSITIVE
        Pattern inlineFlag = Pattern.compile("(?i)hello");
        Matcher m3 = inlineFlag.matcher(text);
        count = 0;
        while (m3.find()) count++;
        result.append("  (?i) 内联标志:     找到 " + count + " 个匹配\n");

        // MULTILINE: ^ 和 $ 匹配每行开头和结尾
        Pattern multiPattern = Pattern.compile("^hello$", Pattern.MULTILINE | Pattern.CASE_INSENSITIVE);
        Matcher m4 = multiPattern.matcher(text);
        count = 0;
        while (m4.find()) count++;
        result.append("  MULTILINE:         找到 " + count + " 个行首行尾匹配\n");

        return result.toString();
    }

    /**
     * 演示 group() 分组捕获
     */
    public static String demoGroups() {
        String text = "我的电话是 010-12345678 和 021-87654321";

        // 使用命名捕获组
        Pattern pattern = Pattern.compile("(?<area>\\d{3,4})-(?<number>\\d{7,8})");
        Matcher matcher = pattern.matcher(text);

        StringBuilder result = new StringBuilder("--- 分组捕获 ---\n\n");
        result.append("  文本: \"").append(text).append("\"\n\n");

        while (matcher.find()) {
            result.append(String.format("  完整匹配: \"%s\"%n", matcher.group(0)));
            result.append(String.format("    区号(编号): \"%s\"%n", matcher.group(1)));
            result.append(String.format("    号码(编号): \"%s\"%n", matcher.group(2)));
            result.append(String.format("    区号(命名): \"%s\"%n", matcher.group("area")));
            result.append(String.format("    号码(命名): \"%s\"%n", matcher.group("number")));
            result.append(String.format("    匹配范围: [%d, %d)%n%n", matcher.start(), matcher.end()));
        }

        return result.toString();
    }

    public static void main(String[] args) {
        System.out.println("========== Pattern & Matcher 核心 API 详解 ==========");
        System.out.println();

        // 1. Pattern 复用
        System.out.println("--- IP 地址验证（Pattern 复用）---");
        String[] ips = {"192.168.1.1", "255.255.255.255", "256.1.2.3", "10.0.0.1", "abc.def.ghi.jkl"};
        for (String ip : ips) {
            System.out.println("  " + ip + " → " + (isValidIp(ip) ? "✓ 合法" : "✗ 非法"));
        }

        System.out.println();
        System.out.println(demoFind());
        System.out.println();

        System.out.println(demoThreeMethods());
        System.out.println();

        System.out.println(demoFlags());
        System.out.println();

        System.out.println(demoGroups());

        System.out.println("--- 关键总结 ---");
        System.out.println("  Pattern.compile(regex)  → 编译正则（应在静态常量中复用）");
        System.out.println("  Pattern.matcher(text)   → 创建匹配器");
        System.out.println("  Matcher.matches()       → 全匹配（隐式 ^...$）");
        System.out.println("  Matcher.find()          → 查找子串（可循环使用）");
        System.out.println("  Matcher.group()         → 获取匹配内容");
        System.out.println("  Matcher.group(n)        → 获取第 n 个捕获组");
        System.out.println("  Matcher.start()/end()   → 匹配位置");
    }
}
