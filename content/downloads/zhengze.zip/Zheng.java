package study.zhengze;

import java.util.Scanner;

public class Zheng {
    public static boolean check(String s){
        return s!=null && s.matches("[1-9]\\d{5,19}");
    }

    public static void main(String[] args) {
        Scanner in =  new Scanner(System.in);
        String s =  in.nextLine();
        System.out.println(check(s));
        in.close();
    }
}
